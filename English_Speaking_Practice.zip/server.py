import os
import sys
import json
import time
import tempfile
import torch
from flask import Flask, render_template, request, jsonify
from questions import LISTEN_AND_REPEAT, TAKE_AN_INTERVIEW

app = Flask(__name__)


def log(msg):
    """Print to stderr so Colab background threads flush output immediately."""
    print(msg, file=sys.stderr, flush=True)


# ---- Local LLM (Qwen2.5 7B Instruct, loaded on first use) ----
_llm_model = None
_llm_tokenizer = None

# Google Drive progress path (set by notebook), falls back to local file
GDRIVE_PROGRESS = os.environ.get("GDRIVE_PROGRESS_PATH")
PROGRESS_FILE = GDRIVE_PROGRESS or os.path.join(os.path.dirname(__file__), "progress.json")

# ---- Whisper model (loaded on first use) ----
whisper_model = None


def get_whisper():
    global whisper_model
    if whisper_model is None:
        from faster_whisper import WhisperModel
        print("Loading Whisper medium on CUDA...")
        whisper_model = WhisperModel("medium", device="cuda", compute_type="float16")
        print("Whisper loaded.")
    return whisper_model


# ---- Phoneme analyzer (loaded on first use via its own lazy init) ----
_phoneme_analyzer = None


def get_phoneme_analyzer():
    global _phoneme_analyzer
    if _phoneme_analyzer is None:
        import phoneme_analyzer
        phoneme_analyzer.load_model()
        _phoneme_analyzer = phoneme_analyzer
    return _phoneme_analyzer


# ---- Progress persistence ----
def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return json.load(f)
    return {"lr_completed": [], "int_completed": []}


def save_progress(data):
    with open(PROGRESS_FILE, "w") as f:
        json.dump(data, f)


# ---- Rubrics ----
LISTEN_REPEAT_RUBRIC = """
TOEFL Speaking Scoring Guide - Listen and Repeat (0-5 scale):

Score 5: The response exactly repeats the prompt. Fully intelligible and exact repetition.

Score 4: The response captures the meaning expressed in the prompt, but it is not an exact repetition.
Minor changes in words or grammar that do not substantially change meaning. Examples: one or two function words missing/changed, a content word replaced with a related word, tense/aspect/number markers incorrect, two words transposed. One or two content words may be ambiguous due to imprecise pronunciation but speaker completes successfully.

Score 3: The response is essentially full, but it does not accurately capture the original meaning.
Contains majority of content words/ideas. Multiple function words changed/missing; one or more content words missing or substantively changed. Is a full sentence. Intelligibility sometimes affected by word-level pronunciation or running words together.

Score 2: The response is missing a significant part of the prompt and/or is highly inaccurate.
Large portion missing with important original meaning left out. May repeat first part then stop or fill with inaccurate content. Not a self-standing sentence; fragmentary. Intelligibility is low.

Score 1: The response captures very little of the prompt or is largely unintelligible.
Minimal response of a few words; most of prompt missing. Recognizable as attempt but mostly unintelligible.

Score 0: No response OR entirely unintelligible OR no English OR content entirely unconnected to prompt.
"""

INTERVIEW_RUBRIC = """
TOEFL Speaking Scoring Guide - Take an Interview (0-5 scale):

Score 5: A fully successful response. Fully addresses the question, clear and fluent.
On topic and well elaborated. Good conversational speaking pace with appropriate pauses. Pronunciation easily intelligible; rhythm and intonation effectively convey meaning. Range of accurate grammar and vocabulary for precise meanings.

Score 4: A generally successful response. Addresses the question, reasonably clear.
On topic and elaborated but may lack effective sentence-level connectors. Good speaking pace generally maintained with some pausing. Intelligibility not impeded by pronunciation/rhythm/intonation though occasional words may require minor effort. Grammar and vocabulary adequate most of the time.

Score 3: A partially successful response. Addresses the question but with limited elaboration and/or clarity.
Generally on topic but elaboration relatively limited. Frequent or lengthy pauses result in choppy pace; filler words frequent. Intelligibility sometimes affected by word-level pronunciation or stress/rhythm inaccuracies. Limited range and accuracy of grammar and vocabulary noticeably restrict precision.

Score 2: A mostly unsuccessful response. Attempt to address the question but not supported meaningfully/intelligibly.
Minimally connected to question with little/no relevant elaboration or consists mainly of language from the question. Intelligibility limited; intended meaning often difficult to discern. Very limited grammar and vocabulary.

Score 1: An unsuccessful response. Minimally addresses question with very limited language control.
Only vaguely connected to interviewer's question. Mostly unintelligible. Consists mainly of isolated words or phrases.

Score 0: No response OR entirely unintelligible OR no English OR content entirely unconnected to prompt.
"""


def format_audio_metrics(audio_metrics, wpm, duration, phoneme_data=None):
    lines = [f"Speaking duration: {duration:.1f} seconds", f"Words per minute: {wpm:.0f}"]

    pitch = audio_metrics.get("pitch", {})
    if "average_hz" in pitch:
        lines.append(f"\nPITCH / INTONATION DATA:")
        lines.append(f"  Average pitch: {pitch['average_hz']} Hz")
        lines.append(f"  Pitch range: {pitch['min_hz']}-{pitch['max_hz']} Hz (range: {pitch['range_hz']} Hz)")
        lines.append(f"  Pitch std deviation: {pitch['std_dev_hz']} Hz")
        lines.append(f"  Pitch direction changes: {pitch['direction_changes']} (more = more natural intonation contour)")
    elif "note" in pitch:
        lines.append(f"\nPITCH: {pitch['note']}")

    rhythm = audio_metrics.get("rhythm", {})
    if rhythm:
        lines.append(f"\nRHYTHM / PAUSE DATA:")
        lines.append(f"  Total pauses detected: {rhythm.get('total_pauses', 'N/A')}")
        lines.append(f"  Long pauses (>700ms): {rhythm.get('long_pauses_over_700ms', 'N/A')}")
        lines.append(f"  Average pause duration: {rhythm.get('average_pause_ms', 'N/A')} ms")
        lines.append(f"  Speech-to-total ratio: {rhythm.get('speech_to_total_ratio', 'N/A')}")

    energy = audio_metrics.get("energy", {})
    if energy:
        lines.append(f"\nENERGY / VOLUME:")
        lines.append(f"  Volume consistency: {energy.get('consistency', 'N/A')}")

    # Whisper word-level data
    whisper_conf = audio_metrics.get("whisper_confidence")
    if whisper_conf is not None:
        lines.append(f"\nWHISPER TRANSCRIPTION CONFIDENCE: {whisper_conf}%")

    # Phoneme-level pronunciation data
    if phoneme_data:
        lines.append(f"\nPHONEME-LEVEL PRONUNCIATION ANALYSIS:")
        lines.append(f"  Phoneme accuracy: {phoneme_data.get('phoneme_accuracy_percent', 'N/A')}%")
        lines.append(f"  Phonemes matched: {phoneme_data.get('matches', 'N/A')} / {phoneme_data.get('total_aligned', 'N/A')}")
        lines.append(f"  Avg phoneme confidence: {phoneme_data.get('avg_phoneme_confidence', 'N/A')}%")
        mispronunciations = phoneme_data.get("mispronunciations", {})
        if mispronunciations:
            lines.append(f"  Specific mispronunciations detected:")
            for pattern, count in list(mispronunciations.items())[:10]:
                lines.append(f"    - {pattern} (occurred {count}x)")
        else:
            lines.append(f"  No significant mispronunciations detected.")

    return "\n".join(lines)


def get_llm():
    global _llm_model, _llm_tokenizer
    if _llm_model is None:
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
        model_name = "Qwen/Qwen2.5-3B-Instruct"
        log(f"Loading {model_name} (4-bit quantized)...")
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.float16,
        )
        _llm_tokenizer = AutoTokenizer.from_pretrained(model_name)
        _llm_model = AutoModelForCausalLM.from_pretrained(
            model_name,
            quantization_config=quantization_config,
            device_map="auto",
        )
        log("LLM loaded.")
    return _llm_model, _llm_tokenizer


def call_llm(messages):
    model, tokenizer = get_llm()
    text = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True,
    )
    inputs = tokenizer(text, return_tensors="pt").to("cuda")
    log(f"LLM generating (input: {inputs['input_ids'].shape[-1]} tokens)...")
    t0 = time.time()
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=1024,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
        )
    out_tokens = outputs[0].shape[-1] - inputs["input_ids"].shape[-1]
    elapsed = time.time() - t0
    log(f"LLM done: {out_tokens} tokens in {elapsed:.1f}s ({out_tokens/elapsed:.1f} tok/s)")
    response = tokenizer.decode(outputs[0][inputs["input_ids"].shape[-1]:], skip_special_tokens=True)
    return response


def parse_llm_json(result):
    import re
    result = result.strip()
    # Strip markdown code fences
    if result.startswith("```"):
        result = result.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    # Extract first JSON object or array from the response
    match = re.search(r"[\[{]", result)
    if match:
        result = result[match.start():]
    return json.loads(result)


def transcribe_audio(audio_path):
    """Transcribe audio using Whisper and return transcript + word data."""
    model = get_whisper()
    segments, info = model.transcribe(audio_path, word_timestamps=True, language="en")

    words = []
    full_text_parts = []
    for segment in segments:
        full_text_parts.append(segment.text)
        if segment.words:
            for w in segment.words:
                words.append({
                    "word": w.word.strip(),
                    "start": round(w.start, 3),
                    "end": round(w.end, 3),
                    "probability": round(w.probability, 3),
                })

    transcript = " ".join(full_text_parts).strip()
    avg_confidence = 0
    if words:
        avg_confidence = round(sum(w["probability"] for w in words) / len(words) * 100)

    return {
        "transcript": transcript,
        "words": words,
        "avg_confidence": avg_confidence,
        "language_probability": round(info.language_probability, 3) if info else 0,
    }


# ---- Routes ----
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/questions")
def get_questions():
    return jsonify({
        "listen_and_repeat": LISTEN_AND_REPEAT,
        "take_an_interview": TAKE_AN_INTERVIEW,
    })


@app.route("/api/progress")
def get_progress():
    return jsonify(load_progress())


@app.route("/api/progress/complete", methods=["POST"])
def mark_complete():
    data = request.json
    progress = load_progress()
    task_type = data.get("type")  # "lr" or "int"
    set_id = data.get("set_id")
    key = "lr_completed" if task_type == "lr" else "int_completed"
    if set_id not in progress[key]:
        progress[key].append(set_id)
    save_progress(progress)
    return jsonify({"ok": True})


@app.route("/api/transcribe", methods=["POST"])
def transcribe():
    """Receive audio blob, transcribe with Whisper, run phoneme analysis."""
    if "audio" not in request.files:
        return jsonify({"error": "No audio file"}), 400

    audio_file = request.files["audio"]
    expected_text = request.form.get("expected_text", "")

    # Save to temp file
    suffix = ".webm" if "webm" in (audio_file.content_type or "") else ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        audio_file.save(tmp)
        tmp_path = tmp.name

    try:
        # Whisper transcription
        log(f"Transcribing audio: {tmp_path} ({os.path.getsize(tmp_path)} bytes)")
        whisper_result = transcribe_audio(tmp_path)
        log(f"Whisper result: '{whisper_result['transcript'][:80]}' (confidence: {whisper_result['avg_confidence']}%)")

        # Phoneme analysis (handles webm via faster-whisper's audio decoder)
        phoneme_data = None
        text_for_phonemes = expected_text or whisper_result["transcript"]
        if text_for_phonemes.strip():
            try:
                analyzer = get_phoneme_analyzer()
                phoneme_data = analyzer.analyze_pronunciation(tmp_path, text_for_phonemes)
                log(f"Phoneme analysis: accuracy={phoneme_data.get('phoneme_accuracy_percent')}%, mismatches={len(phoneme_data.get('mispronunciations', {}))}")
            except Exception as e:
                log(f"Phoneme analysis error: {e}")
                import traceback
                traceback.print_exc()
                phoneme_data = {"error": str(e)}

        return jsonify({
            "transcript": whisper_result["transcript"],
            "words": whisper_result["words"],
            "whisper_confidence": whisper_result["avg_confidence"],
            "phoneme_data": phoneme_data,
        })
    except Exception as e:
        log(f"Transcription error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


@app.route("/api/evaluate/listen-repeat", methods=["POST"])
def evaluate_listen_repeat():
    data = request.json
    original = data["original"]
    transcript = data["transcript"]
    duration = data.get("duration", 0)
    audio_metrics = data.get("audio_metrics", {})
    phoneme_data = data.get("phoneme_data")
    word_count = len(transcript.split()) if transcript else 0
    wpm = (word_count / duration * 60) if duration > 0 else 0

    metrics_text = format_audio_metrics(audio_metrics, wpm, duration, phoneme_data)

    prompt = f"""{LISTEN_REPEAT_RUBRIC}

You are a TOEFL speaking evaluator. Evaluate the student's spoken response against the original prompt.
Use ALL the audio analysis data below — especially the phoneme-level pronunciation analysis — to assess pace, rhythm, intonation, and pronunciation quality.

Original sentence: "{original}"
Student's transcribed response: "{transcript}"

{metrics_text}

EVALUATION GUIDELINES using the audio data:
- PACE: Use WPM and speech-to-total ratio. Natural conversational pace is 120-160 WPM. Below 100 is too slow, above 180 is rushed.
- RHYTHM: Look at pause count, long pauses, and average pause duration. Natural speech has brief pauses. Many long pauses (>700ms) indicate hesitation or struggle.
- INTONATION: Use pitch range and standard deviation. A range of 40-100 Hz with moderate std dev indicates natural intonation. Very low range (<20 Hz) means monotone/flat delivery. Direction changes show natural speech melody.
- PRONUNCIATION: Use the phoneme-level analysis data. Reference SPECIFIC mispronounced phonemes (e.g., "/θ/ was pronounced as /d/"). Use phoneme accuracy percentage and Whisper confidence as overall indicators.

Provide your evaluation in this exact JSON format:
{{
  "score": <0-5 integer>,
  "accuracy": "<brief assessment of word accuracy comparing transcript to original>",
  "pronunciation_notes": "<assessment referencing specific mispronounced phonemes from the phoneme analysis data>",
  "pace_feedback": "<feedback using WPM, duration, speech ratio data>",
  "rhythm_feedback": "<feedback on pause patterns and flow using pause data>",
  "intonation_feedback": "<feedback on pitch variation and speech melody using pitch data>",
  "suggestions": "<specific improvement suggestions referencing exact phonemes to practice>",
  "overall_feedback": "<2-3 sentence overall feedback>"
}}

Return ONLY the JSON, no other text."""

    try:
        result = call_llm([{"role": "user", "content": prompt}])
        return jsonify(parse_llm_json(result))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/evaluate/interview", methods=["POST"])
def evaluate_interview():
    data = request.json
    question = data["question"]
    context = data["context"]
    transcript = data["transcript"]
    duration = data.get("duration", 0)
    audio_metrics = data.get("audio_metrics", {})
    phoneme_data = data.get("phoneme_data")
    word_count = len(transcript.split()) if transcript else 0
    wpm = (word_count / duration * 60) if duration > 0 else 0

    metrics_text = format_audio_metrics(audio_metrics, wpm, duration, phoneme_data)

    prompt = f"""{INTERVIEW_RUBRIC}

You are a TOEFL speaking evaluator. Evaluate the student's interview response.
Use ALL the audio analysis data below — especially the phoneme-level pronunciation analysis — to assess pace, rhythm, intonation, and pronunciation quality.

Interview context: {context}
Interviewer's question: "{question}"
Student's transcribed response: "{transcript}"
(Note: students have up to 45 seconds to respond)

{metrics_text}

EVALUATION GUIDELINES using the audio data:
- PACE: Use WPM and speech-to-total ratio. Natural conversational pace is 120-160 WPM. Below 100 is too slow, above 180 is rushed.
- RHYTHM/FLUENCY: Look at pause count and long pauses. Good fluency = few long pauses, consistent speech flow. Many long pauses or choppy patterns indicate hesitation.
- INTONATION: Use pitch range and std dev. Range of 40-100 Hz with moderate variation = expressive, natural delivery. Very low range = monotone. Direction changes indicate natural speech melody.
- PRONUNCIATION: Use the phoneme-level analysis data. Reference SPECIFIC mispronounced phonemes. Use phoneme accuracy percentage as overall indicator.

Provide your evaluation in this exact JSON format:
{{
  "score": <0-5 integer>,
  "content_feedback": "<feedback on content relevance and elaboration>",
  "fluency_feedback": "<feedback on pace, rhythm, and flow using WPM and pause data>",
  "pronunciation_notes": "<assessment referencing specific mispronounced phonemes>",
  "intonation_feedback": "<feedback on pitch variation and expressiveness using pitch data>",
  "grammar_vocabulary": "<feedback on grammar and vocabulary range>",
  "suggestions": "<2-3 specific improvement suggestions referencing exact phonemes to practice>",
  "overall_feedback": "<2-3 sentence overall feedback>"
}}

Return ONLY the JSON, no other text."""

    try:
        result = call_llm([{"role": "user", "content": prompt}])
        return jsonify(parse_llm_json(result))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/generate-lr-set", methods=["POST"])
def generate_lr_set():
    data = request.json
    topic = data.get("topic", "a campus bookstore")

    prompt = f"""Generate an English "Listen and Repeat" sentence set about: {topic}

The pattern is: a trainer/guide is welcoming or orienting someone to a place or facility. The sentences progress from short and simple to longer and more complex.

Rules:
- Exactly 7 sentences
- Sentence 1: very short greeting or introduction (~5-8 words)
- Sentence 2-3: short, simple statements (~7-10 words each)
- Sentence 4-5: medium length with slightly more detail (~10-14 words each)
- Sentence 6: longer with a clause or extra detail (~12-16 words)
- Sentence 7: the longest, often with a conditional or compound structure (~15-22 words)
- All sentences should be natural, spoken English — the kind a trainer would say
- A context description of the scenario (e.g., "You are being trained to assist customers at a bookstore.")

Return in this exact JSON format:
{{
  "context": "<context sentence>",
  "sentences": ["<s1>", "<s2>", "<s3>", "<s4>", "<s5>", "<s6>", "<s7>"]
}}

Return ONLY the JSON, no other text."""

    try:
        result = call_llm([{"role": "user", "content": prompt}])
        return jsonify(parse_llm_json(result))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/generate-interview-questions", methods=["POST"])
def generate_interview_questions():
    data = request.json
    topic = data.get("topic", "daily life")

    prompt = f"""Generate an English "Take an Interview" question set about: {topic}

The format should be:
- A context sentence (e.g., "You have volunteered for a research study about X...")
- 4 interviewer questions that progressively increase in complexity:
  1. A personal/experience question
  2. A preference/opinion question
  3. A broader societal trend question
  4. A debate/agree-disagree question

Return in this exact JSON format:
{{
  "context": "<context sentence>",
  "questions": ["<q1>", "<q2>", "<q3>", "<q4>"]
}}

Return ONLY the JSON, no other text."""

    try:
        result = call_llm([{"role": "user", "content": prompt}])
        return jsonify(parse_llm_json(result))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    # Preload models at startup so there's no delay during practice
    # Only load in the reloader child process (or when reloader is off)
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug:
        print("Loading models at startup (one-time download on first run)...")
        get_whisper()
        get_phoneme_analyzer()
        get_llm()
        print("All models loaded.")

    print("Open http://localhost:5000 in Chrome")
    app.run(debug=True, port=5000)
