import torch
import soundfile as sf
import numpy as np
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, Wav2Vec2CTCTokenizer
from g2p_en import G2p

g2p = G2p()

# Use the standard English ASR model — no espeak dependency
MODEL_NAME = "facebook/wav2vec2-large-960h"
processor = None
model = None


def load_model():
    global processor, model
    if model is not None:
        return
    print("Loading Wav2Vec2 pronunciation model...")
    processor = Wav2Vec2Processor.from_pretrained(MODEL_NAME)
    model = Wav2Vec2ForCTC.from_pretrained(MODEL_NAME)
    if torch.cuda.is_available():
        model = model.to("cuda")
    model.eval()
    print("Wav2Vec2 pronunciation model loaded.")


def load_audio_as_16k(audio_path):
    """Load audio from any format (webm, wav, etc.) as 16kHz mono numpy array."""
    try:
        # Try soundfile first (works for wav, flac, ogg)
        speech, sr = sf.read(audio_path)
        if len(speech.shape) > 1:
            speech = speech.mean(axis=1)
        if sr != 16000:
            from scipy.signal import resample
            num_samples = int(len(speech) * 16000 / sr)
            speech = resample(speech, num_samples)
        return speech
    except Exception:
        pass

    # Fallback: use faster-whisper's audio decoder (handles webm via bundled ffmpeg)
    from faster_whisper.audio import decode_audio
    return decode_audio(audio_path, sampling_rate=16000)


def audio_to_tokens(audio_path):
    """Extract character-level tokens with confidence from audio."""
    load_model()
    speech = load_audio_as_16k(audio_path)

    inputs = processor(speech, sampling_rate=16000, return_tensors="pt", padding=True)
    if torch.cuda.is_available():
        inputs = {k: v.to("cuda") for k, v in inputs.items()}

    with torch.no_grad():
        logits = model(**inputs).logits

    probs = torch.nn.functional.softmax(logits, dim=-1)
    predicted_ids = torch.argmax(logits, dim=-1)

    # Decode full transcript
    transcription = processor.batch_decode(predicted_ids)[0].lower().strip()

    # Get per-frame confidence and CTC-decoded characters
    max_probs = probs[0].max(dim=-1).values.cpu().numpy()
    ids = predicted_ids[0].cpu().numpy()

    # CTC collapse: merge repeated tokens, skip blanks
    chars = []
    char_confidences = []
    prev_id = -1
    blank_id = processor.tokenizer.pad_token_id

    for i, token_id in enumerate(ids):
        if token_id != prev_id and token_id != blank_id:
            char = processor.tokenizer.decode([token_id]).lower()
            if char.strip():
                chars.append(char)
                char_confidences.append(float(max_probs[i]))
        prev_id = token_id

    return transcription, chars, char_confidences


# ARPAbet to IPA mapping
ARPABET_TO_IPA = {
    'AA': 'ɑ', 'AE': 'æ', 'AH': 'ə', 'AO': 'ɔ', 'AW': 'aʊ',
    'AY': 'aɪ', 'B': 'b', 'CH': 'tʃ', 'D': 'd', 'DH': 'ð',
    'EH': 'ɛ', 'ER': 'ɝ', 'EY': 'eɪ', 'F': 'f', 'G': 'ɡ',
    'HH': 'h', 'IH': 'ɪ', 'IY': 'i', 'JH': 'dʒ', 'K': 'k',
    'L': 'l', 'M': 'm', 'N': 'n', 'NG': 'ŋ', 'OW': 'oʊ',
    'OY': 'ɔɪ', 'P': 'p', 'R': 'ɹ', 'S': 's', 'SH': 'ʃ',
    'T': 't', 'TH': 'θ', 'UH': 'ʊ', 'UW': 'u', 'V': 'v',
    'W': 'w', 'Y': 'j', 'Z': 'z', 'ZH': 'ʒ',
}


def text_to_phonemes(text):
    """Convert text to phoneme sequence using g2p_en."""
    raw = g2p(text)
    phonemes = []
    for p in raw:
        clean = p.rstrip('012')
        if clean in ARPABET_TO_IPA:
            phonemes.append(ARPABET_TO_IPA[clean])
        elif p.isalpha():
            phonemes.append(p.lower())
    return phonemes


def word_phoneme_comparison(expected_text, spoken_text):
    """Compare expected vs spoken text at the phoneme level, word by word."""
    expected_words = expected_text.lower().split()
    spoken_words = spoken_text.lower().split()

    # Align words using edit distance
    word_alignment = align_sequences(expected_words, spoken_words)

    mismatches = []
    total_phonemes = 0
    matched_phonemes = 0

    for item in word_alignment:
        if item["expected"] == "(extra)" or item["spoken"] == "(missing)":
            if item["expected"] != "(extra)":
                exp_ph = text_to_phonemes(item["expected"])
                total_phonemes += len(exp_ph)
            continue

        exp_phonemes = text_to_phonemes(item["expected"])
        spk_phonemes = text_to_phonemes(item["spoken"])
        total_phonemes += len(exp_phonemes)

        if item["expected"] == item["spoken"]:
            matched_phonemes += len(exp_phonemes)
            continue

        # Align phonemes within mismatched words
        ph_alignment = align_sequences(exp_phonemes, spk_phonemes)
        for pa in ph_alignment:
            if pa["match"]:
                matched_phonemes += 1
            elif pa["expected"] != "(extra)" and pa["spoken"] != "(missing)":
                mismatches.append({
                    "word": item["expected"],
                    "expected_phoneme": pa["expected"],
                    "spoken_phoneme": pa["spoken"],
                })

    return {
        "total_phonemes": total_phonemes,
        "matched_phonemes": matched_phonemes,
        "mismatches": mismatches,
    }


def align_sequences(expected, spoken):
    """Align two sequences using edit distance with traceback."""
    n, m = len(expected), len(spoken)

    if n == 0 and m == 0:
        return []
    if n == 0:
        return [{"expected": "(extra)", "spoken": s, "match": False} for s in spoken]
    if m == 0:
        return [{"expected": e, "spoken": "(missing)", "match": False} for e in expected]

    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        dp[i][0] = i
    for j in range(m + 1):
        dp[0][j] = j

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if expected[i - 1] == spoken[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])

    alignment = []
    i, j = n, m
    while i > 0 or j > 0:
        if i > 0 and j > 0 and (expected[i - 1] == spoken[j - 1] or
                                  dp[i][j] == dp[i - 1][j - 1] + 1):
            alignment.append({
                "expected": expected[i - 1],
                "spoken": spoken[j - 1],
                "match": expected[i - 1] == spoken[j - 1],
            })
            i -= 1
            j -= 1
        elif i > 0 and dp[i][j] == dp[i - 1][j] + 1:
            alignment.append({"expected": expected[i - 1], "spoken": "(missing)", "match": False})
            i -= 1
        else:
            alignment.append({"expected": "(extra)", "spoken": spoken[j - 1], "match": False})
            j -= 1

    alignment.reverse()
    return alignment


def analyze_pronunciation(audio_path, expected_text):
    """Full pronunciation analysis."""
    # Get Wav2Vec2 transcription with character confidence
    w2v_transcript, chars, char_confidences = audio_to_tokens(audio_path)

    # Phoneme comparison between expected and Wav2Vec2 transcript
    comparison = word_phoneme_comparison(expected_text, w2v_transcript)

    # Summarize mispronunciations
    mispronounced = {}
    for m in comparison["mismatches"]:
        key = f"/{m['expected_phoneme']}/ → /{m['spoken_phoneme']}/"
        if key not in mispronounced:
            mispronounced[key] = {"count": 0, "words": []}
        mispronounced[key]["count"] += 1
        if m["word"] not in mispronounced[key]["words"]:
            mispronounced[key]["words"].append(m["word"])

    avg_char_confidence = float(np.mean(char_confidences)) if char_confidences else 0
    total = comparison["total_phonemes"]
    matched = comparison["matched_phonemes"]
    accuracy = round(matched / total * 100) if total > 0 else 0

    # Format mispronunciations for display
    mispronounced_simple = {}
    for pattern, info in mispronounced.items():
        example_words = ", ".join(info["words"][:3])
        mispronounced_simple[pattern] = f'{info["count"]}x (in: {example_words})'

    return {
        "phoneme_accuracy_percent": accuracy,
        "total_phonemes_expected": total,
        "matched_phonemes": matched,
        "total_aligned": total,
        "matches": matched,
        "mispronunciations": mispronounced_simple,
        "avg_phoneme_confidence": round(avg_char_confidence * 100),
        "wav2vec2_transcript": w2v_transcript,
    }
